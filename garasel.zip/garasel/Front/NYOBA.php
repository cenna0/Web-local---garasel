<?php
session_start();
require_once "../koneksi.php";

// Validate and sanitize input
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid cart ID");
}

// Sanitize cart ID
$idKeranjang = mysqli_real_escape_string($con, $_GET['id']);

// Ensure user is logged in
if (!isset($_SESSION['id_pembeli'])) {
    header("Location: login.php");
    exit();
}

$idPembeli = $_SESSION['id_pembeli'];

// Fetch cart and product details with proper error handling
$queryKeranjang = "SELECT k.Id_keranjang, k.Id_produk, p.Stok, p.Kondisi, p.Ukuran, p.Foto_produk, p.Nama_produk, p.Harga, k.Jumlah_produk 
    FROM keranjang k 
    JOIN produk p ON k.Id_produk = p.Id_produk 
    WHERE k.Id_keranjang = ? AND k.Id_pembeli = ?";

$stmt = mysqli_prepare($con, $queryKeranjang);
mysqli_stmt_bind_param($stmt, "ii", $idKeranjang, $idPembeli);
mysqli_stmt_execute($stmt);
$resultKeranjang = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($resultKeranjang) == 0) {
    die("Cart not found or not authorized");
}

$data = mysqli_fetch_assoc($resultKeranjang);
$hargaProduk = $data['Harga'];
$idProduk = $data['Id_produk'];

// Voucher handling
$pesan = "";
$diskon = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['cekVoucher'])) {
        $voucherInput = mysqli_real_escape_string($con, $_POST['voucher']);
        $queryVoucher = "SELECT diskon FROM voucher WHERE kode = ?";

        $stmtVoucher = mysqli_prepare($con, $queryVoucher);
        mysqli_stmt_bind_param($stmtVoucher, "s", $voucherInput);
        mysqli_stmt_execute($stmtVoucher);
        $resultVoucher = mysqli_stmt_get_result($stmtVoucher);

        if (mysqli_num_rows($resultVoucher) > 0) {
            $dataVoucher = mysqli_fetch_assoc($resultVoucher);
            $diskon = $dataVoucher['diskon'];
            $pesan = "Selamat, Anda mendapatkan diskon sebesar $diskon%";
        } else {
            $pesan = "Kode voucher tidak valid!";
        }
    }

    // Transaction Creation
    if (isset($_POST['buatPembayaran'])) {
        $jenisPembayaran = mysqli_real_escape_string($con, $_POST['jenisPembayaran']);
        $jenisKurir = mysqli_real_escape_string($con, $_POST['jenisKurir']);
        $totalHarga1 = mysqli_real_escape_string($con, $_POST['totalHarga']);

        // Validate required fields
        if (empty($jenisKurir) || empty($jenisPembayaran)) {
            $pesan = "Pilih kurir dan metode pembayaran terlebih dahulu";
        } else {
            $tanggalTransaksi = date('Y-m-d');
            $statusTransaksi = 'Pending';

            $totalDiskon = ($diskon / 100) * $totalHarga1;
            $totalHarga = $totalHarga1 - $totalDiskon;


            $queryTransaksi = "INSERT INTO transaksi_penjualan 
                (Id_pembeli, Id_produk, Id_keranjang, Metode_pembayaran, Kurir, Total_harga, Tanggal_transaksi, Status_transaksi) 
                                   VALUES ('$idPembeli', '$idProduk', '$idKeranjang', '$jenisPembayaran', '$jenisKurir', '$totalHarga', '$tanggalTransaksi', '$statusTransaksi')";

            $stmtTransaksi = mysqli_prepare($con, $queryTransaksi);

            if (mysqli_stmt_execute($stmtTransaksi)) {
                $idTransaksi = mysqli_insert_id($con);
                header("Location: pembayaran.php?id_transaksi=$idTransaksi");
                exit();
            } else {
                $pesan = "Gagal membuat transaksi: " . mysqli_error($con);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi</title>
    <link rel="stylesheet" href="../css/transaction.css">
    <style>
        .container {
            display: flex;
            padding: 20px;
            padding-top: 1px;
            justify-content: center;
        }

        .product-image,
        .product-details {
            flex: 1;
            padding: 20px;
            position: -webkit-sticky;
            position: sticky;
            top: 20px;
        }

        .product-image {
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            max-width: 300px;
        }

        .product-image img {
            max-width: 100%;
            border-radius: 10px;
            transition: top 0.3s ease;
        }

        .product-details {
            text-align: left;
            display: flex;
            flex-direction: column;
            justify-content: center;
            margin-left: 20px;
            max-width: 300px;

        }

        .product-details h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .product-details p {
            font-size: 18px;
            margin: 5px 0;
        }

        .shipping {
            padding: 20px;
            border-left: 1px solid #ddd;
        }

        .shipping h2 {
            font-size: 24px;
            margin-bottom: 20px;
            margin-top: 1px;
        }

        .shipping .shipping-methods,
        .shipping .payment-methods {
            margin-bottom: 20px;
        }

        .shipping .shipping-methods img,
        .shipping .payment-methods button {
            object-fit: cover;
            width: 80px;
            height: 80px;
            margin-right: 10px;
            border: 1px solid #ddd;
            border-radius: 10px;
            cursor: pointer;
            padding: 5px;
        }

        .shipping .payment-methods button {
            width: auto;
            height: auto;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            cursor: pointer;
        }

        .shipping .payment-methods button.selected,
        .shipping .shipping-methods img.selected {
            background-color: #f5c6c6;
        }

        .shipping .summary {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 10px;
            font-size: 16px;
        }

        .shipping .summary p {
            margin: 5px 0;
        }

        .shipping .total {
            font-weight: bold;
            font-size: 18px;
        }


        .shipping .pay-button {
            display: block;
            width: 100%;
            padding: 15px;
            background-color: #f5c6c6;
            color: #000;
            text-align: center;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
        }

        .shipping .price {
            text-align: left;
            margin-top: 5px;
            font-size: 14px;
            color: #555;
            margin-left: 7px;
        }

        .shipping .price1 {
            text-align: left;
            margin-top: 5px;
            font-size: 14px;
            color: #555;
            margin-left: 45px;
        }

        .voucher {
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f5f5f5;
            font-size: 12px;
        }

        .voucher-b {
            background-color: #f5f5f5;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button.voucher-b:hover {
            background-color: #45a049;
        }

        .message {
            margin-top: 20px;
            font-size: 12px;
            color: #4caf50;
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>
    <?php require "navbar.php"; ?>

    <div class="container">
        <div class="product-image">
            <img alt="<?= htmlspecialchars($data['Nama_produk']); ?>"
                src="../image/<?= htmlspecialchars($data['Foto_produk']); ?>">
        </div>

        <div class="product-details">
            <h2><?= htmlspecialchars($data['Nama_produk']); ?></h2>
            <p>Ukuran: <?= htmlspecialchars($data['Ukuran']); ?></p>
            <p>Kondisi: <?= htmlspecialchars($data['Kondisi']); ?></p>
        </div>

        <div class="shipping">
            <h2>PENGIRIMAN</h2>

            <div class="shipping-methods">
                <h3>Pilih Metode Pengiriman</h3>
                <img src="../image/sicepat.png" onclick="pilihKurir(10000, this, 'SiCepat')">
                <img src="../image/jnt.png" onclick="pilihKurir(12000, this, 'J&T')">
                <img src="../image/JNE.png" onclick="pilihKurir(15000, this, 'JNE')">
                <img src="../image/ninja.png" onclick="pilihKurir(8000, this, 'Ninja Express')">
            </div>

            <div class="payment-methods">
                <h3>Pilih Metode Pembayaran</h3>
                <button onclick="pilihPembayaran(3000, this, 'Debit')">Debit</button>
                <button onclick="pilihPembayaran(5000, this, 'Kredit')">Kredit</button>
                <button onclick="pilihPembayaran(2000, this, 'Virtual Account')">Virtual Account</button>
            </div>

            <div class="summary">
                <h3>Rincian Harga</h3>
                <p>Harga Produk: Rp <?= number_format($hargaProduk, 0, ',', '.'); ?></p>
                <p>Jumlah Produk: <?= htmlspecialchars($data['Jumlah_produk']); ?></p>
                <p>Jenis Pengiriman: <span id="jenis-pengiriman">Belum dipilih</span></p>
                <p>Jenis Pembayaran: <span id="jenis-pembayaran">Belum dipilih</span></p>
                <p>Pajak (10%): Rp <span id="tax"><?= number_format($hargaProduk * $data['Jumlah_produk'] * 0.1, 0, ',', '.'); ?></span></p>

                <form action="" method="post">
                    <input class="voucher" placeholder="Voucher" type="text" name="voucher" />
                    <button class="voucher-b" name="cekVoucher" type="submit">Cek Voucher</button>
                </form>

                <?php if ($pesan): ?>
                    <div class="message <?= strpos($pesan, 'diskon') !== false ? 'success' : 'error'; ?>">
                        <?= htmlspecialchars($pesan); ?>
                    </div>
                <?php endif; ?>

                <p class="total">Total Harga: <span id="total-harga"></span></p>
            </div>

            <form action="" method="POST">
                <input type="hidden" name="jenisPembayaran" id="jenisPembayaranInput">
                <input type="hidden" name="jenisKurir" id="jenisKurirInput">
                <input type="hidden" name="totalHarga" id="totalHargaInput" value="<?= $totalHarga ?>">

                <button class="pay-button" name="buatPembayaran" type="submit">Melakukan Pembayaran</button>
            </form>
        </div>
    </div>

    <script>
        // Global variables for calculations
        let biayaKurir = 0;
        let biayaPembayaran = 0;
        let hargaProduk = <?= $hargaProduk ?>;
        const jumlahProduk = <?= $data['Jumlah_produk'] ?>;
        const taxRate = 0.1; // 10% pajak

        function updateTotal() {
            const subtotal = hargaProduk * jumlahProduk;
            const tax = subtotal * taxRate;
            const diskon = <?= $diskon ?>; // Pastikan diskon ini didapat dari PHP
            const total = subtotal + tax + biayaKurir + biayaPembayaran - (subtotal * diskon / 100);

            document.getElementById('total-harga').textContent =
                `Rp ${total.toLocaleString('id-ID')}`;
            document.getElementById('totalHargaInput').value = total;
        }


        function pilihKurir(biaya, element, namaKurir) {
            biayaKurir = biaya;
            document.getElementById('jenis-pengiriman').textContent =
                `${namaKurir}: Rp ${biaya.toLocaleString('id-ID')}`;
            highlightSelected(element, '.shipping-methods img');
            document.getElementById('jenisKurirInput').value = namaKurir;
            updateTotal();
        }

        function pilihPembayaran(biaya, element, namaPembayaran) {
            biayaPembayaran = biaya;
            document.getElementById('jenis-pembayaran').textContent =
                `${namaPembayaran}: Rp ${biaya.toLocaleString('id-ID')}`;
            highlightSelected(element, '.payment-methods button');
            document.getElementById('jenisPembayaranInput').value = namaPembayaran;
            updateTotal();
        }

        function highlightSelected(element, group) {
            document.querySelectorAll(group).forEach(el => el.classList.remove('selected'));
            element.classList.add('selected');
        }

        document.addEventListener('DOMContentLoaded', () => {
            updateTotal();
        });
    </script>
</body>

</html>