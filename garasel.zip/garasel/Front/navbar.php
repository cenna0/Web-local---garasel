<!DOCTYPE html>
<html lang="en">

<head>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>navbar</title>
    <style>
        /* Header Section */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: white;
            padding: 10px 20px;
            border-bottom: 1px solid #ccc;
        }

        .header h1 {
            font-size: 24px;
            margin: 0;
        }

        .header .search-bar {
            display: flex;
            align-items: center;
        }

        .header .search-bar input {
            padding: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .header .buttons {
            display: flex;
            gap: 10px;
        }

        .header .buttons button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .header .buttons .jual {
            padding: 10px 20px;
        }
        .header .buttons .keranjang {
            background-color: white;
            color: black;
            border: 1px solid black;
        }

        .header .buttons .pesananSaya {
            background-color: black;
            color: white;
        }

        /* Navigation Section */
        .nav {
            display: flex;
            justify-content: center;
            background-color: white;
            padding: 10px 0;
            border-bottom: 1px solid #ccc;
        }

        .nav a {
            margin: 0 15px;
            font-size: 18px;
            color: black;
            text-decoration: none;
        }
        .nav a.active {
            font-weight: bold;
            text-decoration: underline;
        }
        body {
            font-family: 'Courier New', Courier, monospace;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
    </style>
</head>

<body>
    <!-- Header Section -->
    <div class="header">
        <h1 onclick="window.location.href='produk.php'">Garasel</h1>
        <div class="buttons">
            <h1 class="jual" onclick="window.location.href='penjual.php'">Jual</h1>
            <button class="keranjang" onclick="window.location.href='keranjang.php'">Keranjang</button>
            <button class="pesananSaya" onclick="window.location.href='pesananSaya.php'">pesanan Saya</button>
        </div>
    </div>

    <!-- Navigation Section -->
    <div class="nav">
        <a href="produk.php?kategori=baju">
            Baju
        </a>
        <a href="produk.php?kategori=celana" >
            Celana
        </a>
        <a href="produk.php?kategori=sepatu">
            Sepatu
        </a>
        <a href="produk.php?kategori=aksesoris">
            Aksesoris
        </a>
    </div>

   
</body>


</html>