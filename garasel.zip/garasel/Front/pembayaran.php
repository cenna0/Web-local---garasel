<?php
ob_start();
require "../koneksi.php";
require "session.php";

// Ambil ID Transaksi dari URL
if (isset($_GET['id_transaksi'])) {
    $idTransaksi = mysqli_real_escape_string($con, $_GET['id_transaksi']);

    // Query untuk mengambil detail transaksi
    $queryTransaksi = mysqli_query($con, "SELECT * FROM transaksi_penjualan WHERE Id_penjualan = '$idTransaksi'");
    $data = mysqli_fetch_array($queryTransaksi);
    $idProduk = $data['Id_produk'];
    // Query untuk mengambil detail produk
    $queryProduk = mysqli_query($con, "SELECT * FROM produk WHERE Id_produk = '$idProduk'");
} else {
    echo "ID Transaksi tidak diberikan.";
    exit;
}

// Jika tombol "Bayar" ditekan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update status transaksi
    $updateStatus = mysqli_query($con, "UPDATE transaksi_penjualan SET Status_transaksi = 'Dikirim' WHERE Id_penjualan = '$idTransaksi'");

    // Kurangi stok produk
    while ($produk = mysqli_fetch_assoc($queryProduk)) {
        $idProduk = $produk['Id_produk'];
        $jumlahBeli = $produk['Stok'];

        $updateStok = mysqli_query($con, "UPDATE produk SET Stok = Stok - $jumlahBeli WHERE Id_produk = '$idProduk'");
    }

    if ($updateStatus && $updateStok) {
        echo "<script>alert('Pembayaran Sukses');</script>";
        header("Location: pesananSaya.php");
        exit;
    } else {
        echo "Terjadi kesalahan saat memproses pembayaran.";
    }
}
?>

<html>
<head>
    <title>pembayaran</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        .container {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 84vh;
        }
        .payment-box {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            background-color: #f0f0f0;
            text-align: center;
            width: 300px;
            background-color: #F7CDCD;
        }
        .payment-box h2 {
            margin-top: 0;
            font-size: 18px;
        }
        .payment-box .payment-code {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .payment-box .payment-code span {
            font-size: 18px;
        }
        .payment-box .payment-code button {
            background-color: #e0e0e0;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .payment-box .details {
            text-align: left;
            margin: 10px 0;
        }
        .payment-box .details p {
            margin: 5px 0;
        }
        .payment-box .pay-button {
            background-color: #000;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php require "navbar.php" ?>
    <div class="container">
        <div class="payment-box">
            <h2>PEMBAYARAN</h2>
            <div class="payment-code">
                <span id="payment-code">218078380</span>
                <button onclick="copyToClipboard()">salin</button>
            </div>
            <div class="details">
                <p>Jenis Pembayaran : <?php echo $data['Metode_pembayaran'] ?></p>
                <p>Total: Rp <?php echo number_format($data['Total_harga'], 0, ',', '.'); ?></p>
            </div>
            <!-- Form untuk mengubah status transaksi -->
            <form method="POST">
                <button type="submit" class="pay-button">Bayar</button>
            </form>
        </div>
        <script>
            function copyToClipboard() {
                const code = document.getElementById('payment-code').innerText;
                const tempInput = document.createElement('input');
                tempInput.value = code;
                document.body.appendChild(tempInput);
                tempInput.select();
                document.execCommand('copy');
                document.body.removeChild(tempInput);
            }
        </script>
    </div>
</body>
</html>
