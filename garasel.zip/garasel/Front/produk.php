<?php
ob_start();
require "session.php"; 
require "../koneksi.php";

if (isset($_GET['kategori'])) {
    $kategori = mysqli_real_escape_string($con, $_GET['kategori']);
    $queryKategori = mysqli_query($con, "SELECT * FROM produk WHERE Kategori='$kategori'");
} else {
    $queryKategori = mysqli_query($con, "SELECT * FROM produk");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />

    <title>Produk</title>

    <style>
        .products {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 20px;
        }

        .product {
            width: 200px;
            margin: 10px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
            padding: 10px;
        }

        .product img {
            width: 100%;
            height: 200px;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }

        .product .price {
            font-size: 18px;
            font-weight: bold;
            margin: 10px 0;
        }

        .product .description {
            font-size: 14px;
            color: #666;
        }

        .product .cart-icon {
            margin-top: 10px;
            font-size: 20px;
            color: #666;
            cursor: pointer;
        }

        .button {
            background-color: white;
            border-radius: 10px;
            border: 1px solid #ccc;
            padding: 5px 10px;
            cursor: pointer;
        }

        .form button {
            background-color: transparent;
            border: none;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php require "navbar.php"; ?>

    <div class="products" id="products">
        <!-- Menampilkan produk -->
        <?php
        if (mysqli_num_rows($queryKategori) > 0) {
            while ($produk = mysqli_fetch_array($queryKategori)) {
        ?>
                <div class="product">
                    <!-- Gambar Produk -->
                    <img alt="<?php echo htmlspecialchars($produk['Nama_produk']); ?>" src="../image/<?php echo htmlspecialchars($produk['Foto_produk']); ?>" />
                    
                    <!-- Harga Produk -->
                    <div class="price">
                        Rp <?php echo number_format($produk['Harga'], 0, ',', '.'); ?>
                    </div>
                    
                    <!-- Deskripsi Produk -->
                    <div class="description">
                        <?php echo htmlspecialchars($produk['Nama_produk']); ?>
                    </div>
                    
                    <!-- Tombol Detail -->
                    <button class="button" onclick="window.location.href='detail.php?produk=<?php echo urlencode($produk['Nama_produk']); ?>'">Detail</button>
                    
                    <!-- Form Keranjang -->
                    <div class="form">
                        <form action="" method="post">
                            <input type="hidden" name="id_produk" value="<?php echo $produk['Id_produk']; ?>" />
                            <button type="submit" name="tambah" class="fas fa-shopping-cart cart-icon"></button>
                        </form>
                    </div>
                </div>
        <?php
            }
        } else {
            echo "<p>Tidak ada produk dalam kategori ini.</p>";
        }
        ?>
    </div>

    <?php
    // Menambahkan produk ke keranjang
    if (isset($_POST['tambah'])) {
        $id_produk = mysqli_real_escape_string($con, $_POST['id_produk']);
        $id_pembeli = $_SESSION['id_pembeli'];
        $jumlahProduk = 1; // Default jumlah produk ditambahkan 1

        // Pastikan id_produk tidak kosong
        if (!empty($id_produk)) {
            // Query untuk menambahkan ke keranjang
            $queryTambah = "INSERT INTO keranjang (Id_produk, Id_pembeli, Jumlah_produk) VALUES ('$id_produk', '$id_pembeli', '$jumlahProduk')";
            $result = mysqli_query($con, $queryTambah);

            if ($result) {
                // Berhasil menambahkan produk ke keranjang
                header("Location: produk.php"); // Redirect untuk mencegah submit ulang
                exit();
            } else {
                echo "<p>Gagal menambahkan produk ke keranjang.</p>";
            }
        }
    }
    ?>

</body>

</html>
