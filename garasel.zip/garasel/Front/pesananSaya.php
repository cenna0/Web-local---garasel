<?php

ob_start();
require "session.php";
require "../koneksi.php";

$idPengguna = $_SESSION['id_pembeli'];
$queryPesanan = mysqli_query($con, "
   SELECT 
        tp.Total_harga, 
        tp.Id_penjualan,
        tp.Status_transaksi,
        p.Foto_produk, 
        p.Harga, 
        p.Nama_produk, 
        k.Jumlah_produk 
    FROM transaksi_penjualan tp
    JOIN keranjang k ON tp.Id_keranjang = k.Id_keranjang
    JOIN produk p ON k.Id_produk = p.Id_produk
    WHERE tp.Id_pembeli = '$idPengguna'
    ORDER BY tp.Tanggal_transaksi DESC;
");

if (isset($_POST['idPenjualan'])) {
    $idPenjualan = $_POST['idPenjualan'];
    $updateStatus = mysqli_query($con, "UPDATE transaksi_penjualan SET Status_transaksi = 'Diterima' WHERE Id_penjualan = '$idPenjualan'");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <title>Pesanan Saya</title>
    <style>
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: white;
            padding: 10px 20px;
            border-bottom: 1px solid #ccc;
        }

        .header h1 {
            font-size: 24px;
            margin: 0;
        }

        .header .search-bar {
            display: flex;
            align-items: center;
        }

        .header .search-bar input {
            padding: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .header .buttons {
            display: flex;
            gap: 10px;
        }

        .header .buttons button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .header .buttons .jual {
            padding: 10px 20px;
        }

        .header .buttons .keranjang {
            background-color: #fff;
            color: black;
            border: 1px solid black;
        }

        .header .buttons .pesananSaya {
            background-color: #ffe3e3;
            color: black;
        }

        body {
            font-family: 'Courier New', Courier, monospace;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        .order-container {
            padding: 20px;
            padding-bottom: 0px;
            background-color: white;
            margin: 10px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .order-header .left {
            display: flex;
            align-items: center;
        }

        .order-header .left .btn {
            background-color: #f1f1f1;
            color: #333;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            margin-right: 10px;
            cursor: pointer;
        }

        .order-header .right {
            color: #4caf50;
            font-size: 14px;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid #ddd;
            padding: 10px 0;
        }

        .order-item img {
            width: 100px;
            height: 100px;
            margin-right: 10px;
        }

        .order-item .details {
            flex-grow: 1;
        }

        .order-item .details p {
            margin: 0;
            font-size: 25px;
        }

        .order-item .price {
            font-size: 25px;
            color: #333;
        }
        .status {
            font-size: 14px;
            color: #4caf50;
            margin: 0px;
        }
        .status p{
            margin: 0px;
        }
        .total {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 10px 0;
            font-size: 20px;
            color: #ff5722;
        }

        .status-button {
            color: #ff5722;
            border: 1px solid #ff5722;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            background-color: transparent;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1 onclick="window.location.href='produk.php'">Garasel</h1>
        <div class="buttons">
            <h1 class="jual" onclick="window.location.href='penjual.php'">Jual</h1>
            <button class="keranjang" onclick="window.location.href='keranjang.php'">Keranjang</button>
            <button class="pesananSaya" onclick="window.location.href='pesananSaya.php'">pesanan Saya</button>
        </div>
    </div>
    <?php
    if (mysqli_num_rows($queryPesanan) > 0) {
        while ($data = mysqli_fetch_array($queryPesanan)) {
            // Detail pesanan
    ?>
            <div class="order-container">
                <div class="order-header">
                    <div class="left">
                        <button class="btn visit"
                            onclick="window.location.href='detail.php?produk=<?php echo urlencode($data['Nama_produk']); ?>'">
                            Kunjungi Toko
                        </button>
                    </div>
                    <div class="right">
                        <form method="POST">
                            <input type="hidden" name="idPenjualan" value="<?php echo $data['Id_penjualan']; ?>">
                            <button class="status-button" type="submit">
                                <i class="fas fa-truck">
                                </i>
                                Pesanan telah sampai
                            </button>
                        </form>
                    </div>
                </div>
                <div class="order-item">
                    <img alt="<?php echo htmlspecialchars($data['Nama_produk']); ?>" src="../image/<?php echo htmlspecialchars($data['Foto_produk']); ?>" />
                    <div class="details">
                        <p>
                            <?php echo htmlspecialchars($data['Nama_produk']); ?>
                        </p>
                        <p>
                            <?php echo htmlspecialchars($data['Jumlah_produk']); ?>
                        </p>
                    </div>
                    <div class="price">
                        <p>Rp <?php echo number_format($data['Harga'], 0, ',', '.'); ?></p>
                    </div>
                 
                </div>
                <div class="status">
                        <p>Status: <?php echo htmlspecialchars($data['Status_transaksi']) ?></p>
                    </div>
                <div class="total">
                    Total Pesanan:
                    <span>
                        <p>Rp <?php echo number_format($data['Total_harga'], 0, ',', '.'); ?></p>
                    </span>
                </div>
            </div>
    <?php
        }
    }

    ?>
</body>

</html>