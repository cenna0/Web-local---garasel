<?php
ob_start();
require "session.php"; 
require "../koneksi.php";
$query = mysqli_query($con, "SELECT * FROM produk");
$jumlahProduk = mysqli_num_rows($query);
function generateRandomString($length = 10)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';

    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }

    return $randomString;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>navbar</title>
    <style>
        /* Header Section */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: white;
            padding: 10px 20px;
            border-bottom: 1px solid #ccc;
        }

        .header h1 {
            font-size: 24px;
            margin: 0;
        }

        .header .search-bar {
            display: flex;
            align-items: center;
        }

        .header .search-bar input {
            padding: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .header .buttons {
            display: flex;
            gap: 10px;
        }

        .header .buttons button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .header .buttons .jual {
            padding: 10px 20px;
        }

        .header .buttons .keranjang {
            background-color: white;
            color: black;
            border: 1px solid black;
        }

        .header .buttons .pesananSaya {
            background-color: black;
            color: white;
        }

        body {
            font-family: 'Courier New', Courier, monospace;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;

        }

        .container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 20px;

        }

        .box {
            width: 80%;
            max-width: 800px;
            padding: 20px;
            padding-top: 5px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form {
            margin-top: 30px;
        }

        .form h1 {
            font-size: 25px;
            font-weight: bold;
            margin-top: 10px;
            margin-left: 1px;
            margin-bottom: 2px;
        }

        .form h2 {
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
            margin-left: 1px;
            margin-bottom: 2px;

        }

        .form select,
        .form input {
            width: 100%;
            padding: 10px;
            padding-right: 1px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 5px;
            font-size: 14px;
        }

        .submit {
            margin-top: 5px;
            background-color: black;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            gap: 10px;
        }

        .form-container,
        .list-container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);

        }

        .form-container h2,
        .list-container h2 {
            font-family: 'Courier New', Courier, monospace;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .form-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-container input[type="text"],
        .form-container input[type="file"],
        .form-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .form-container input[type="submit"] {
            background-color: black;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Courier New', Courier, monospace;
        }

        .list-container .product-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .list-container .product-item img {
            width: 100px;
            height: 100px;
            border-radius: 5px;
            margin-right: 20px;
        }

        .list-container .product-item .product-info {
            flex: 1;
        }

        .list-container .product-item .product-info-2 {
            flex: 10px;
        }

        .list-container .product-item .product-info h3 {
            margin: 0;
            font-size: 18px;
            margin-right: 10px;


        }

        .list-container .product-item .product-info h4 {
            margin: 0;
            font-size: 18px;
        }

        .list-container .product-item .product-info p {
            margin: 5px 0;
            color: #888;
        }

        .list-container .product-item .product-actions {
            display: flex;
            gap: 10px;
        }

        .list-container .product-item .product-actions input[type="text"] {
            width: 60px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .list-container .product-item .product-actions button {
            background-color: black;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <!-- Header Section -->
    <div class="header">
        <h1 onclick="window.location.href='produk.php'">Garasel</h1>
        <div class="buttons">
            <button class="keranjang" onclick="window.location.href='keranjang.php'">Keranjang</button>
            <button class="pesananSaya" onclick="window.location.href='pesananSaya.php'">Pesanan Saya</button>
        </div>
    </div>
    <div class="container">
        <div class="box">
            <form action="" method="post" enctype="multipart/form-data" class="form">
                <h1>Produk</h1>
                <div>
                    <input type="text" name="produk" autocomplete="off" placeholder="Nama Produk" required>
                </div>
                <div>
                    <label for="foto">Masukkan Foto</label>
                    <input type="file" name="foto" id="foto" accept="image/*" required>
                </div>
                <h2>Detail</h2>
                <div>
                    <select name="kategori" required>
                        <option value="" disabled selected>Kategori</option>
                        <option value="baju">baju</option>
                        <option value="celana">celana</option>
                        <option value="sepatu">sepatu</option>
                        <option value="aksesoris">aksesoris</option>
                    </select>
                </div>
                <div>
                    <select name="ukuran" required>
                        <option value="" disabled selected>Ukuran</option>
                        <option value="S">S</option>
                        <option value="M">M</option>
                        <option value="L">L</option>
                        <option value="XL">XL</option>
                    </select>
                </div>
                <div>
                    <select name="kondisi" required>
                        <option value="" disabled selected>Kondisi</option>
                        <option value="baru">Baru</option>
                        <option value="lama">Lama</option>
                    </select>
                </div>
                <div>
                    <input type="number" placeholder="Stok" name="stok" required>
                </div>
                <div>
                    <input type="number" placeholder="Harga" name="harga" required>
                </div>
                <div>
                    <button type="submit" class="submit" name="submit">submit</button>
                </div>
            </form>
            <?php
            if (isset($_POST['submit'])) {
                $produk = htmlspecialchars($_POST['produk']);
                $kategori = htmlspecialchars($_POST['kategori']);
                $ukuran = htmlspecialchars($_POST['ukuran']);
                $kondisi = htmlspecialchars($_POST['kondisi']);
                $stok = htmlspecialchars($_POST['stok']);
                $harga = htmlspecialchars($_POST['harga']);

                $target_dir = "../image/";
                $nama_file = basename($_FILES["foto"]["name"]);
                $target_file = $target_dir . $nama_file;
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                $random_name = generateRandomString(20);
                $foto_new_name = $random_name . "." . $imageFileType;

                move_uploaded_file(
                    $_FILES["foto"]["tmp_name"],
                    $target_dir . $foto_new_name
                );

                $queryProdukBaru = "INSERT INTO produk (Nama_produk, Kategori, Ukuran, Kondisi, Harga, Stok, Foto_produk)  
                VALUES ('$produk', '$kategori', '$ukuran', '$kondisi', '$harga', '$stok', '$foto_new_name')";
                $result = mysqli_query($con, $queryProdukBaru);

                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            }
            ?>
        </div>
    </div>
    <div class="list-container">
        <h2>
            List Produk yang Dijual
        </h2>
        <?php
        if ($jumlahProduk == 0) {

        ?>
            <h3>Data Produk Tidak Tersedia, Silakan tambah produk</h3>
            <?php
        } else {
            $jumlah = 1;
            while ($data = mysqli_fetch_array($query)) {
            ?>

                <div class="product-item">
                    <img height="100" src="../image/<?php echo $data['Foto_produk'] ?>" width="100" alt="foto prduk <?php $data['Nama_produk'] ?>" />
                    <div class="product-info">
                        <h3>
                            <?php echo $data['Nama_produk'] ?>
                        </h3>
                        <p>
                        Rp <?php echo number_format($data['Harga'], 0, ',', '.'); ?>
                        </p>
                    </div>
                    <div class="product-info-2">
                        <h3>
                            Stok : <?php echo $data['Stok'] ?>
                        </h3>

                    </div>
                    <div class="product-actions">
                        <form action="" method="post">
                            <input type="hidden" name="id_produk" value="<?php echo $data['Id_produk']; ?>" />
                            <input placeholder="Harga" type="text" name="harga" />
                            <input placeholder="Stok" type="text" name="stok" />
                            <button name="edit">edit</button>
                        </form>
                        <?php
                        if (isset($_POST['edit'])) {
                            $id_produk = htmlspecialchars($_POST['id_produk']);
                            $harga = htmlspecialchars($_POST['harga']);
                            $stok = htmlspecialchars($_POST['stok']);

                            if (!empty($id_produk)) {
                                if (!empty($harga) && empty($stok)) {
                                    $queryEditHarga = "UPDATE `produk` SET `Harga` = '$harga' WHERE `Id_produk` = $id_produk";
                                    $result1 = mysqli_query($con, $queryEditHarga);
                                } elseif (empty($harga) && !empty($stok)) {
                                    $queryEditStok = "UPDATE `produk` SET `Stok` = '$stok' WHERE `Id_produk` = $id_produk";
                                    $result2 = mysqli_query($con, $queryEditStok);
                                } elseif (!empty($harga) && !empty($stok)) {
                                    $queryEditBoth = "UPDATE `produk` SET `Harga` = '$harga', `Stok` = '$stok' WHERE `Id_produk` = $id_produk";
                                    $result3 = mysqli_query($con, $queryEditBoth);
                                }
                                header("Location: " . $_SERVER['PHP_SELF']);
                                exit();
                            }
                        }
                        ?>
                            <form action="" method="post">
                                <input type="hidden" name="id_produk" value="<?php echo $data['Id_produk']; ?>" />
                                <button name="hapus">Hapus Barang</button>
                            </form>
                        <?php
                            if (isset($_POST['hapus'])) {
                                $id_produk = htmlspecialchars($_POST['id_produk']);
                                if (!empty($id_produk)) {
                                    $queryHapus = "DELETE FROM `produk` WHERE `Id_produk` = $id_produk";
                                    $result = mysqli_query($con, $queryHapus);
                                    header("Location: " . $_SERVER['PHP_SELF']);
                                    exit();
                                }
                            }
                        ?>
                    </div>
                </div>
            <?php
                $jumlah++;
            }
        }
        ?>
    </div>

</body>

</html>