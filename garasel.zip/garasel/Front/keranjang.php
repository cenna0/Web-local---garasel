<?php
ob_start();
require "session.php"; 
require "../koneksi.php";
$id_pembeli = $_SESSION['id_pembeli'];
$queryKeranjang = mysqli_query(
    $con,
    "SELECT k.Id_keranjang, k.Id_produk, p.Stok, p.Kondisi, p.Ukuran, p.Foto_produk, p.Nama_produk, p.Harga, k.Jumlah_produk FROM keranjang k 
JOIN produk p ON k.Id_produk = p.Id_produk WHERE k.Id_pembeli = '$id_pembeli'"
);
$queryGetArray = mysqli_query($con, "SELECT * FROM keranjang");
?>

<html>

<head>
    <title>
        Garasel 
    </title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <style>
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: white;
            padding: 10px 20px;
            border-bottom: 1px solid #ccc;
        }

        .header h1 {
            font-size: 24px;
            margin: 0;
        }

        .header .search-bar {
            display: flex;
            align-items: center;
        }

        .header .search-bar input {
            padding: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .header .buttons {
            display: flex;
            gap: 10px;
        }

        .header .buttons button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .header .buttons .jual {
            padding: 10px 20px;
        }

        .header .buttons .keranjang {
            background-color: #ffe3e3;
            color: black;
            border: 1px solid black;
        }

        .header .buttons .pesananSaya {
            background-color: black;
            color: white;
        }


        body {
            font-family: 'Courier New', Courier, monospace;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        .table-container {
            margin: 20px;
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .table-header {
            display: grid;
            grid-template-columns: 1fr 2fr 1fr 1fr 1fr 1fr;
            padding: 10px 0;
            border-bottom: 1px solid #ccc;
            font-weight: bold;
            text-align: center;
        }

        .table-row {
            display: grid;
            grid-template-columns: 1fr 2fr 1fr 1fr 1fr 1fr;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
            text-align: center;
        }

        .table-row img {
            width: 100px;
            height: 100px;
            border-radius: 10px;
            margin: 0 auto;
        }

        .table-row .product-details {
            text-align: center;
        }

        .table-row .product-details h3 {
            margin: 0;
            font-size: 18px;
        }

        .table-row .product-details p {
            margin: 5px 0 0;
            color: #666;
        }

        .table-row .price,
        .table-row .quantity,
        .table-row .total-price,
        .table-row .action {
            text-align: center;
        }

        .table-row .quantity {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .table-row .quantity input {
            width: 50px;
            text-align: center;
            margin-bottom: 5px;
        }

        .table-row .quantity button {
            padding: 5px 10px;
            background-color: #000;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .table-row .action {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .table-row .action .button1 {
            padding: 5px 10px;
            background-color: #000;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 5px;
        }

        .table-row .action .trash-icon {
            font-size: 24px;
            color: #000;
            cursor: pointer;
        }
        .form button {
            background-color: transparent;
            border-style: hidden;
        }
    </style>
</head>

<body>

    <body>
        <div class="header">
            <h1 onclick="window.location.href='produk.php'">Garasel</h1>
            <div class="buttons">
                <h1 class="jual" onclick="window.location.href='penjual.php'">Jual</h1>
                <button class="keranjang" onclick="window.location.href='keranjang.php'">Keranjang</button>
                <button class="pesananSaya" onclick="window.location.href='pesananSaya.php'">pesanan Saya</button>
            </div>
        </div>

        <?php
        if (mysqli_num_rows($queryKeranjang) == 0) {
            echo "<p>Keranjang kamu kosong!</p>";
        } else {
        ?>
            <div class="table-container">
                <div class="table-header">
                    <div>FOTO PRODUK</div>
                    <div>DETAIL PRODUK</div>
                    <div>HARGA SATUAN</div>
                    <div>KUANTITAS</div>
                    <div>TOTAL HARGA</div>
                    <div>AKSI</div>
                </div>

                <?php
                while ($data = mysqli_fetch_array($queryKeranjang)) {
                ?>
                    <div class="table-row">
                        <div>
                            <img alt="<?php echo htmlspecialchars($data['Nama_produk']); ?>" src="../image/<?php echo htmlspecialchars($data['Foto_produk']); ?>" />
                        </div>
                        <div class="product-details">
                            <h3><?php echo htmlspecialchars($data['Nama_produk']); ?></h3>
                            <p>
                                Ukuran : <?php echo htmlspecialchars($data['Ukuran']); ?>
                            </p>
                            <p>
                                Kondisi : <?php echo htmlspecialchars($data['Kondisi']); ?>
                            </p>
                        </div>
                        <div class="price">
                            <p>Rp <?php echo number_format($data['Harga'], 0, ',', '.'); ?></p>
                            <p>tersedia: <?php echo htmlspecialchars($data['Stok']) ?></p>
                        </div>
                    
                        <form action="" method="post">
                            <input type="hidden" name="id_keranjang" value="<?php echo $data['Id_keranjang']; ?>" />
                            <div class="quantity">
                                <input name="kuantitas" type="text" value="<?php echo htmlspecialchars($data['Jumlah_produk']) ?>" />
                                <button name="edit">Ubah</button>
                            </div>
                        </form>
                        <?php
                        if (isset($_POST['edit'])) {
                            $id_produk = htmlspecialchars($_POST['id_keranjang']);
                            $kuantitas = htmlspecialchars($_POST['kuantitas']);


                            if (!empty($id_produk)) {

                                $queryEditKuantitas = "UPDATE `keranjang` SET `Jumlah_produk` = '$kuantitas' WHERE `Id_keranjang` = $id_produk";
                                $result = mysqli_query($con, $queryEditKuantitas);
                                header("Location: " . $_SERVER['PHP_SELF']);
                                exit();
                            }
                        }
                        ?>

                        <div class="total-price">
                            <?php
                            $total_harga = $data['Jumlah_produk'] * $data['Harga'];
                            ?>
                            <p>Rp <?php echo number_format($total_harga, 0, ',', '.'); ?></p>
                        </div>
                            <div class="action">
                                <button class="button1" onclick="window.location.href='transaksi.php?id=<?php echo $data['Id_keranjang'] ?>'">Check Out</button>
                                <div class="form">
                                <form action="" method="post">
                                <input type="hidden" name="id_keranjang" value="<?php echo $data['Id_keranjang']; ?>" />
                                <button name="hapus" class="fas fa-trash trash-icon"></button>
                                </div>  
                            </div>
                        </form>
                        <?php
                            if (isset($_POST['hapus'])) {
                                $id_produk = htmlspecialchars($_POST['id_keranjang']);
                                if (!empty($id_produk)) {
                                    $queryHapus = "DELETE FROM `keranjang` WHERE `Id_keranjang` = $id_produk";
                                    $result = mysqli_query($con, $queryHapus);
                                    header("Location: " . $_SERVER['PHP_SELF']);
                                    exit();
                                }
                            }
                        ?>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
</body>

</html>