<?php
ob_start();
require "session.php";
require "../koneksi.php";

$nama = mysqli_real_escape_string($con, $_GET['produk']);
$query = mysqli_query($con, "SELECT * FROM produk WHERE Nama_produk='$nama'");
$produk = mysqli_fetch_array($query);

// Mengambil produk berdasarkan kategori jika ada
if (isset($_GET['kategori'])) {
    $kategori = mysqli_real_escape_string($con, $_GET['kategori']);
    $queryKategori = mysqli_query($con, "SELECT * FROM produk WHERE Kategori='$kategori'");
} else {
    $queryKategori = mysqli_query($con, "SELECT * FROM produk");
}

if (isset($_POST['tambah'])) {
    $id_produk = $_POST['id_produk'];
    $id_pembeli = $_SESSION['id_pembeli'];
    $stokBeli = 1;

    $queryCek = "SELECT * FROM keranjang WHERE Id_produk='$id_produk' AND Id_pembeli='$id_pembeli'";
    $resultCek = mysqli_query($con, $queryCek);

    if (mysqli_num_rows($resultCek) > 0) {
        $queryUpdate = "UPDATE keranjang SET Jumlah_produk = Jumlah_produk + $stokBeli WHERE Id_produk='$id_produk' AND Id_pembeli='$id_pembeli'";
        $result = mysqli_query($con, $queryUpdate);
    } else {
        $queryTambah = "INSERT INTO keranjang (Id_produk, Id_pembeli, Jumlah_produk) VALUES ('$id_produk', '$id_pembeli', '$stokBeli')";
        $result = mysqli_query($con, $queryTambah);
    }

    if ($result) {
        header("Location: keranjang.php");
        exit();
    } else {
        echo "Gagal menambahkan produk ke keranjang.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffffff;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .product-image {
            width: 300px;
            height: 400px;
            background-color: #d3d3d3;
            border-radius: 10px;
            overflow: hidden;
            margin-right: 20px;
            object-position: center;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .product-details {
            max-width: 300px;
        }

        .product-details h2 {
            font-size: 24px;
            margin: 0;
        }

        .product-details p {
            font-size: 18px;
            margin: 5px 0;
        }

        .product-details .price {
            font-size: 20px;
            font-weight: bold;
            margin: 10px 0;
        }

        .product-details .condition {
            font-size: 16px;
            color: #666;
            margin-bottom: 20px;
        }

        .product-details .buttons {
            display: flex;
            flex-direction: column;
        }

        .product-details .buttons button,
        .product-details .buttons input {
            padding: 10px;
            font-size: 16px;
            margin-bottom: 10px;
            border: 1px solid #000;
            border-radius: 5px;
            cursor: pointer;
        }

        .product-details .buttons .button {
            color: #000;
        }

        .product-details .buttons input {
            background-color: #fff;
            color: #000;
        }
    </style>
</head>

<body>
    <?php require "navbar.php"; ?>

    <div class="container">
        <div class="product-image">
            <img alt="<?php echo htmlspecialchars($produk['Nama_produk']); ?>" src="../image/<?php echo htmlspecialchars($produk['Foto_produk']); ?>">
        </div>

        <div class="product-details">
            <h2><?php echo htmlspecialchars($produk['Nama_produk']); ?></h2>
            <p class="price">Rp <?php echo number_format($produk['Harga'], 0, ',', '.'); ?></p>
            <p class="condition">
                Ukuran: <?php echo htmlspecialchars($produk['Ukuran']); ?><br>
                Kondisi: <?php echo htmlspecialchars($produk['Kondisi']); ?>
            </p>

            <div class="buttons">
                <div class="button">
                    <form action="#" method="post">
                        <input type="hidden" name="id_produk" value="<?php echo htmlspecialchars($produk['Id_produk']); ?>">
                        <button type="submit" name="tambah">Masukkan ke Keranjang</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>