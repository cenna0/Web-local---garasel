<?php
ob_start();
require "session.php"; 
require "../koneksi.php";
$queryProduk = mysqli_query($con, "SELECT Nama_produk, Kondisi, Harga, Foto_produk FROM produk LIMIT 3");
?>
<html>

<head>
    <title>Garasel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <style>
        /* Header Section */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: white;
            padding: 10px 20px;
            border-bottom: 1px solid #ccc;
        }

        .header h1 {
            font-size: 24px;
            margin: 0;
        }

        .header .search-bar {
            display: flex;
            align-items: center;
        }

        .header .search-bar input {
            padding: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .header .buttons {
            display: flex;
            gap: 10px;
        }

        .header .buttons button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .header .buttons .login {
            background-color: white;
            color: black;
            border: 1px solid black;
        }

        .header .buttons .signup {
            background-color: black;
            color: white;
        }

        body {
            font-family: 'Courier New', Courier, monospace;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        /* Main Content Section */
        .main-content {
            position: relative;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 20px;
        }

        .main-content img {
            width: 100%;
        }

        /* Footer Section */
        .footer {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: white;
            padding: 20px;
            border-top: 1px solid #ccc;
        }

        .footer img {
            margin: 0 20px;
            height: 50px;
        }

        /* Popup Overlay and Box */
        .popup-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .popup-box {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 300px;
            position: relative;
        }

        .popup-box .close-btn {
            position: absolute;
            top: 10px;
            left: 10px;
            cursor: pointer;
        }

        .popup-box h2 {
            text-align: center;
            margin: 0 0 20px 0;
        }

        .popup-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .popup-box button {
            width: 100%;
            padding: 10px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .popup-box .switch {
            text-align: center;
            margin-top: 10px;
        }

        .popup-box .switch a {
            color: blue;
            cursor: pointer;
        }

        .error-message {
            display: none;
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            margin-top: 10px;
            text-align: center;
        }

        .success-message {
            display: none;
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            margin-top: 10px;
            text-align: center;
        }
        .headerProduk{
            text-align: center;
            margin-bottom: auto;
        }
        .products {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 5px;
        }

        .product {
            width: 200px;
            margin: 10px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
            padding: 10px;
        }

        .product img {
            height: 200px;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
            object-fit: cover;
            object-position: center;
        }

        .product .price {
            font-size: 18px;
            font-weight: bold;
            margin: 10px 0;
        }

        .product .description {
            font-size: 14px;
            color: #666;
        }

        .product .cart-icon {
            margin-top: 10px;
            font-size: 20px;
            color: #666;
        }

    </style>
</head>

<body>
    <!-- Header Section -->
    <div class="header">
        <h1 onclick="window.location.href='index.php'">Garasel</h1>
        <div class="buttons">
            <button class="login" onclick="showLoginPopup()">Login</button>
            <button class="signup" onclick="showSignupPopup()">Sign up</button>
        </div>
    </div>


    <!-- banner -->
    <div class="main-content">
        <img alt="banner" src="../image/banner.jpeg" />
    </div>

    <!-- Footer Section -->
    <div class="footer">
        <img alt="Adidas logo" height="500" src="../image/adidas.jpeg" width="100" />
        <img alt="Vans logo" height="50" src="../image/vans.jpeg" width="100" />
        <img alt="Nike logo" height="50" src="../image/nike.jpeg" width="100" />
        <img alt="Puma logo" height="50" src="../image/puma.jpeg" width="100" />
        <img alt="Uniqlo logo" height="50" src="../image/uniqlo.jpeg" width="100" />
        <img alt="Calvin Klein logo" height="50" src="../image/calvin.jpeg" width="100" />
        <img alt="U.S. Polo Assn. logo" height="50" src="../image/polo.jpeg" width="100" />
        <img alt="New Balance logo" height="50" src="../image/newbalance.jpeg" width="100" />
    </div>
    <div>
        <h1 class="headerProduk">PRODUCT</h1>
    </div>
    <div class="products" id="products">
        <?php
        
            while ($data = mysqli_fetch_array($queryProduk)) {
            ?>
                <div class="product">

                    <img alt="produk" height="200" src="../image/<?php echo $data['Foto_produk'] ?>"  width="200" />
                    <div class="price">
                    Rp <?php echo number_format($data['Harga'], 0, ',', '.'); ?>
                    </div>
                    <div class="description">
                        <?php echo $data['Nama_produk'] ?>
                    </div>
                    <i class="fas fa-shopping-cart cart-icon" onclick="showLoginPopup()"></i>
                </div>

        <?php
            }
        ?>
    </div>

    <!-- Login Popup -->
    <div class="popup-overlay" id="loginPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closePopup('loginPopup')">&times;</span>
            <h2>Login</h2>
            <form action="" method="post">
                <input placeholder="Username" type="text" name="username" />
                <input placeholder="Password" type="password" name="password" />
                <button name="Masuk">Masuk</button>
            </form>
            <div>
                <?php
                    if (isset($_POST['Masuk'])) {
                        $username = htmlspecialchars($_POST['username']);
                        $password = htmlspecialchars($_POST['password']);
                        $query = mysqli_query($con, "SELECT * FROM pembeli WHERE Nama_pembeli='$username'");
                        $countdata = mysqli_num_rows($query);
                        $data = mysqli_fetch_array($query);
                        if ($countdata > 0) {
                            if (password_verify($password, $data['password_pembeli'])) {
                                $_SESSION['username'] = $data['Nama_pembeli'];
                                $_SESSION['login'] = true;
                                $_SESSION['id_pembeli'] = $data['Id_pembeli'];

                                header('location: produk.php');
                            } else {
                                echo "Password salah!";
                            }
                        } else {
                            echo "Username tidak ditemukan!";
                        }
                    }
                ?>
            </div>
            <div class="switch">
                Don't have an account? <a onclick="showSignupPopup()">Sign up here</a>
            </div>
        </div>
    </div>

    <!-- Signup Popup -->
    <div class="popup-overlay" id="signupPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closePopup('signupPopup')">&times;</span>
            <h2>Sign Up</h2>
            <form action="" method="post">
                <input placeholder="Username" type="text" name="nama" required />
                <input placeholder="Password" type="password" name="pw" required />
                <input placeholder="Nomor HP" type="text" name="nomor" required />
                <input placeholder="E-mail" type="email" name="email" required />
                <input placeholder="Alamat" type="text" name="alamat" required />
                <button type="submit" name="submitDaftar">Daftar</button>

            </form>
            <div>
                <?php
                if (isset($_POST['submitDaftar'])) {
                    $nama = htmlspecialchars($_POST['nama']);
                    $pw = password_hash(htmlspecialchars($_POST['pw']), PASSWORD_DEFAULT);
                    $nomor = htmlspecialchars($_POST['nomor']);
                    $email = htmlspecialchars($_POST['email']);
                    $alamat = htmlspecialchars($_POST['alamat']);

                    $query = "INSERT INTO pembeli (Nama_pembeli, password_pembeli, NomorTlp_pembeli, Email_pembeli, Alamat_pembeli) VALUES ('$nama', '$pw', '$nomor', '$email', '$alamat')";
                    $result = mysqli_query($con, $query);
                }
                ?>
            </div>
        </div>
    </div>


    <script>
        // Menampilkan popup login
        function showLoginPopup() {
            document.getElementById('loginPopup').style.display = 'flex';
            document.getElementById('signupPopup').style.display = 'none';
        }

        // Menampilkan popup sign up
        function showSignupPopup() {
            document.getElementById('signupPopup').style.display = 'flex';
            document.getElementById('loginPopup').style.display = 'none';
        }

        // Menutup popup berdasarkan id
        function closePopup(popupId) {
            document.getElementById(popupId).style.display = 'none';
        }
    </script>

</body>

</html>