<?php

$con = mysqli_connect("localhost", "root", "", "garasel");
    
// Check connection
if (mysqli_connect_errno()) {
    echo "Failed connect to Mysql: " . mysqli_connect_error();
    exit();
  }
  ?>

