-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2024 at 06:01 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `garasel`
--

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `Id_keranjang` int(11) NOT NULL,
  `Id_produk` int(11) NOT NULL,
  `Id_pembeli` int(11) NOT NULL,
  `Jumlah_produk` int(11) NOT NULL,
  `Total_Harga` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`Id_keranjang`, `Id_produk`, `Id_pembeli`, `Jumlah_produk`, `Total_Harga`) VALUES
(108, 78, 8, 10, 0.00),
(111, 81, 8, 3, 0.00),
(112, 79, 8, 1, 0.00),
(113, 83, 8, 3, 0.00),
(114, 81, 8, 3, 0.00),
(117, 83, 8, 3, 0.00),
(118, 83, 8, 1, 0.00),
(119, 81, 8, 1, 0.00),
(120, 84, 8, 1, 0.00),
(121, 82, 8, 1, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE `pembeli` (
  `Id_pembeli` int(11) NOT NULL,
  `Nama_pembeli` varchar(100) NOT NULL,
  `password_pembeli` varchar(255) NOT NULL,
  `Email_pembeli` varchar(100) NOT NULL,
  `Alamat_pembeli` text NOT NULL,
  `NomorTlp_pembeli` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`Id_pembeli`, `Nama_pembeli`, `password_pembeli`, `Email_pembeli`, `Alamat_pembeli`, `NomorTlp_pembeli`) VALUES
(8, 'a', '$2y$10$NDRb2bJUhvDqcWAanKG9B.rMTQXS3G/.56Vr5IW7lKzb2s2FGwZRS', '2310501082@mahasiswa.upnvj.ac.id', 'a', 'a'),
(9, 'Fadillah', '$2y$10$QEIHQg1BTL.a/ydLJUQmRe9g.NR/OX4P6cblskJv8nzIYXhVriyGC', 'fadillahahmadavicenna@gmail.com', 'jkt', '08128'),
(10, 'davin', '$2y$10$bsxVBIroSlLMbkO1egm94OFqd5qRkKkZeIwaEdH.PdyZXovXn1Uq6', 'davin@gmail.com', 'jkt', '08');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `Id_produk` int(11) NOT NULL,
  `Nama_produk` varchar(100) NOT NULL,
  `Kategori` varchar(50) NOT NULL,
  `Ukuran` varchar(10) NOT NULL,
  `Kondisi` varchar(20) NOT NULL,
  `Harga` decimal(10,2) NOT NULL,
  `Stok` int(11) NOT NULL,
  `Foto_produk` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`Id_produk`, `Nama_produk`, `Kategori`, `Ukuran`, `Kondisi`, `Harga`, `Stok`, `Foto_produk`) VALUES
(78, 'celana vintage', 'celana', 'M', 'baru', 12093.00, 0, 'ReruawV6H8mTGYStGByL.jpeg'),
(79, 'sepatu putih', 'sepatu', 'M', 'baru', 50000.00, 0, 'rvvNRmgiL8xZSJorUclR.jpeg'),
(81, 'kaos putih', 'baju', 'S', 'baru', 70000.00, 0, '0jppPAfA4MHeYgGD1n76.jpeg'),
(82, 'Kaos Hitam', 'baju', 'S', 'baru', 70000.00, 4, 'm1NJxwNEytYfXkESKjE6.jpeg'),
(83, 'gelang', 'aksesoris', 'L', 'lama', 10000.00, 0, 'lo5l584VVsz4qiKAasUH.jpeg'),
(84, 'kalung silver', 'aksesoris', 'M', 'baru', 8000.00, 10, '8gtcGJtvOR8MHMP8rhoZ.jpeg'),
(86, 'sepatu olahraga', 'sepatu', 'M', 'baru', 200000.00, 1, '5m357GNcTKYj7GYBTXzW.jpeg'),
(87, 'celana cargo putih', 'celana', 'M', 'lama', 89000.00, 8, 'n23RyAkG93Mx7PMHWKk5.jpeg'),
(88, 'celana kulot ', 'celana', 'XL', 'lama', 120000.00, 2, 'QH13F80o3YZxbZpKcfB6.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_penjualan`
--

CREATE TABLE `transaksi_penjualan` (
  `Id_penjualan` int(11) NOT NULL,
  `Id_produk` int(11) NOT NULL,
  `Id_pembeli` int(11) NOT NULL,
  `Id_keranjang` int(11) NOT NULL,
  `Metode_pembayaran` varchar(50) NOT NULL,
  `Kurir` varchar(50) NOT NULL,
  `Tanggal_transaksi` date NOT NULL,
  `Status_transaksi` varchar(20) NOT NULL,
  `Total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_penjualan`
--

INSERT INTO `transaksi_penjualan` (`Id_penjualan`, `Id_produk`, `Id_pembeli`, `Id_keranjang`, `Metode_pembayaran`, `Kurir`, `Tanggal_transaksi`, `Status_transaksi`, `Total_harga`) VALUES
(30, 78, 8, 108, 'Debit', 'SiCepat', '2024-11-30', 'Diterima', 26302),
(31, 78, 8, 108, 'Kredit', 'J&T', '2024-11-30', 'DiterimaDikirim', 30302),
(32, 78, 8, 108, 'Debit', 'SiCepat', '2024-11-30', 'Dikirim', 26302),
(33, 78, 8, 108, 'Debit', 'J&T', '2024-11-30', 'Diterima', 28302),
(34, 78, 8, 108, 'Debit', 'SiCepat', '2024-11-30', 'Diterima', 26302),
(35, 81, 8, 111, 'Debit', 'SiCepat', '2024-11-30', 'Diterima', 244000),
(36, 79, 8, 112, 'Debit', 'SiCepat', '2024-11-30', 'Diterima', 68000),
(37, 83, 8, 118, 'Debit', 'SiCepat', '2024-11-30', 'Dikirim', 24000),
(38, 82, 8, 121, 'Virtual Account', 'JNE', '2024-12-01', 'Pending', 94000),
(39, 82, 8, 121, 'Debit', 'SiCepat', '2024-12-01', 'Pending', 90000),
(40, 82, 8, 121, 'Kredit', 'J&T', '2024-12-01', 'Pending', 94000),
(41, 82, 8, 121, 'Debit', 'SiCepat', '2024-12-01', 'Diterima', 90000),
(42, 82, 8, 121, 'Debit', 'SiCepat', '2024-12-01', 'Diterima', 55000),
(43, 78, 8, 108, 'Kredit', 'J&T', '2024-12-01', 'Dikirim', 89558),
(44, 78, 8, 108, 'Debit', 'SiCepat', '2024-12-01', 'Dikirim', 85558);

-- --------------------------------------------------------

--
-- Table structure for table `voucher`
--

CREATE TABLE `voucher` (
  `id_voucher` int(11) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `diskon` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voucher`
--

INSERT INTO `voucher` (`id_voucher`, `kode`, `diskon`) VALUES
(1, 'DISKON10', 10.00),
(2, 'FREEONGKIR', 20.00),
(3, 'BIGSALE50', 50.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`Id_keranjang`),
  ADD KEY `Id_produk` (`Id_produk`),
  ADD KEY `Id_pembeli` (`Id_pembeli`);

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`Id_pembeli`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`Id_produk`);

--
-- Indexes for table `transaksi_penjualan`
--
ALTER TABLE `transaksi_penjualan`
  ADD PRIMARY KEY (`Id_penjualan`),
  ADD KEY `Id_produk` (`Id_produk`),
  ADD KEY `Id_pembeli` (`Id_pembeli`),
  ADD KEY `Id_keranjang` (`Id_keranjang`);

--
-- Indexes for table `voucher`
--
ALTER TABLE `voucher`
  ADD PRIMARY KEY (`id_voucher`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `Id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `pembeli`
--
ALTER TABLE `pembeli`
  MODIFY `Id_pembeli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `Id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `transaksi_penjualan`
--
ALTER TABLE `transaksi_penjualan`
  MODIFY `Id_penjualan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `voucher`
--
ALTER TABLE `voucher`
  MODIFY `id_voucher` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD CONSTRAINT `keranjang_ibfk_1` FOREIGN KEY (`Id_produk`) REFERENCES `produk` (`Id_produk`),
  ADD CONSTRAINT `keranjang_ibfk_2` FOREIGN KEY (`Id_pembeli`) REFERENCES `pembeli` (`Id_pembeli`);

--
-- Constraints for table `transaksi_penjualan`
--
ALTER TABLE `transaksi_penjualan`
  ADD CONSTRAINT `transaksi_penjualan_ibfk_1` FOREIGN KEY (`Id_produk`) REFERENCES `produk` (`Id_produk`),
  ADD CONSTRAINT `transaksi_penjualan_ibfk_2` FOREIGN KEY (`Id_pembeli`) REFERENCES `pembeli` (`Id_pembeli`),
  ADD CONSTRAINT `transaksi_penjualan_ibfk_4` FOREIGN KEY (`Id_keranjang`) REFERENCES `keranjang` (`Id_keranjang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
